<?php if(!\Schema::hasTable((new \App\User)->getTable())): ?>
    <div class="alert alert-danger fade show" role="alert">
        <?php echo e(__('You did not run the migrations and seeders! The login information will not be available!')); ?>

    </div>
<?php endif; ?><?php /**PATH /home3/acptic24/public_html/resources/views/alerts/migrations_check.blade.php ENDPATH**/ ?>