<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <title>Impressão do pedido <?php echo e($pedido->id); ?></title>
</head>
<style>
  .header-pedido{
    text-align: center;
    width: 100%;
    display: inline;
  }
  .details{
    width: 100%;
  }
  .pedido{
    width: 100%;
  }
  .itens{
    width: 100%;
    display: block;
  }
</style>
<body>
  <div class="details">
    <div class="pedido">
      Data e Hora: <?php echo e($pedido->created_at->format('d/m/Y H:i:s')); ?> <br>
    </div>
    <div class="cliente">
      <h5>Dados do cliente</h5>
      Nome: <?php echo e($pedido->contato->nome); ?><br>
      Endereço: <?php echo e($pedido->endereco->endereco); ?>; Nº <?php echo e($pedido->endereco->numero); ?><br>
      Bairro: <?php echo e($pedido->endereco->bairro); ?>; Tel: <?php echo e($pedido->contato->telefone); ?>

      <hr>
    </div>
    <div class="itens">
      <h5>Detalhes dos Itens</h5>
      <p style="text-align: center">Descrição - Obs - Qtde - Unit - Total</p>
      <hr>
      <?php $__currentLoopData = $pedido->produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p style="text-align: center">
        <?php echo e($item->descricao); ?> - 
        <?php echo e($item->pivot->obsitem != null ? $item->pivot->obsitem : 'Sem Obs'); ?> - 
        <?php echo e($item->pivot->qtde); ?> - 
        R$ <?php echo e(number_format($item->pivot->prvenda, 2, ',', '.')); ?> - 
        R$ <?php echo e(number_format($item->pivot->prvenda * $item->pivot->qtde, 2, ',', '.')); ?></p>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="pagamento">
      <h5>Detalhes de Pagamento</h5>
      <p>Forma de Pagamento: <?php echo e($pedido->forma_pagamento); ?></p>
      <p>Desconto <?php echo e($pedido->desconto); ?></p>
      <p>Total <?php echo e($pedido->total - $pedido->desconto); ?></p>

    </div>
  </div>
</body>
</html><?php /**PATH /home3/acptic24/public_html/resources/views/pages/pedidos/pdf/order.blade.php ENDPATH**/ ?>