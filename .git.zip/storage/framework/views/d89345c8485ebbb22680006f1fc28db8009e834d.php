<div class="content">
  <div class="row">
    <div class="form-group col-md-2">
      <label for="status">Status*</label>
      <select id="status" class="form-control" name="status" required>
        <option value="1" >Ativo</option>
        <option value="0" >Inativo</option>
      </select>
    </div>
    <div class="form-group col-md-3">
      <label for="tipo">Tipo de Produto*</label>
      <select id="tipo" class="form-control" name="tipo" required>
        <option value="Produto Final" >Produto Final</option>
        <option value="Adicional" >Produto Adicional</option>
        <option value="Outros" >Outros</option>
      </select>
    </div>
    <div class="form-group col-md-3">
      <label for="grupo_id">Grupo</label>
      <select id="grupo_id" class="form-control" name="grupo_id" required>
        <option value="0" >Escolha um grupo</option>
        <?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($item->id); ?>" <?php echo e((old('grupo_id') == $item->id ) ? 'selected' : ''); ?> ><?php echo e($item->descricao); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  </div>
  
  <div class="row">
    <div class="col-md-5">
      <div class="form-group">
        <label for="descricao">Descrição*</label>
        <input type="text" class="form-control" id="descricao" name="descricao" value="<?php echo e(isset($produto) ? $produto->descricao : old('nome')); ?>" placeholder="Descrição do Produto" required>
        <?php echo $__env->make('alerts.feedback', ['field' => 'descricao'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
    <div class="col-md-7">
      <div class="form-group">
        <label for="composicao">Composição*</label>
        <input type="text" class="form-control" id="composicao" name="composicao" value="<?php echo e(isset($produto) ? $produto->composicao : old('composicao')); ?>" placeholder="Ingredientes que compões este produto" required>
        <?php echo $__env->make('alerts.feedback', ['field' => 'composicao'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
  </div>
  
  <div class="row">
    <div class="col-md-3">
      <label for="precocusto" class="col-sm-12 col-form-label">Pr. Custo</label>
      <div class="input-group input-group-md">
        <div class="input-group-prepend">
          <span class="input-group-text">R$</span>
        </div>
        <input type="text" name="precocusto" class="form-control precocusto" value="<?php echo e(isset($produto) ? $produto->precocusto : old('precocusto')); ?>" id="precocusto">
        <?php echo $__env->make('alerts.feedback', ['field' => 'precocusto'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
    
    <div class="col-md-3">
      <label for="precovenda" class="col-sm-12 col-form-label">Pr. Venda</label>
      <div class="input-group input-group-md">
        <div class="input-group-prepend">
          <span class="input-group-text">R$</span>
        </div>
        <input type="text" name="precovenda" class="form-control precovenda" value="<?php echo e(isset($produto) ? $produto->precovenda : old('precovenda')); ?>" id="precovenda">
        <?php echo $__env->make('alerts.feedback', ['field' => 'precovenda'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\wamp64\www\projetos\delivery\resources\views/pages/produtos/formProduto.blade.php ENDPATH**/ ?>