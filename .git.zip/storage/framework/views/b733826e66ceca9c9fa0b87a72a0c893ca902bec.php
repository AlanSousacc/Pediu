<footer class="footer">
  <div class=" container-fluid ">
    
    
  </div>
</footer><?php /**PATH /home3/acptic24/public_html/resources/views/layouts/footer.blade.php ENDPATH**/ ?>