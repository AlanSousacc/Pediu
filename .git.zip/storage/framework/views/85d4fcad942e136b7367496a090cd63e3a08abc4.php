<?php $__env->startSection('content'); ?>
<div class="col-md-3 offset-md-9 fixed-top mt-3" style="z-index: 9999;">
  <?php echo $__env->make('layouts.messages.master-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<div class="panel-header panel-header-sm">
</div>
<div class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <?php if(isset($id)): ?>  
            <a class="btn btn-primary btn-round text-white pull-right" href="<?php echo e(route('novo.endereco', $id)); ?>">Adicionar Endereço</a>
          <?php endif; ?>
          <h4 class="card-title"> Listagem de Endereços</h4>
        </div>
        <div class="card-body">
          <div class="table-responsive" style="overflow: initial!important;">
            <table class="table">
              <thead class=" text-primary">
                <th class="text-center">Nome contato</th>
                <th class="text-center">Endereco</th>
                <th class="text-center">Número</th>
                <th class="text-center">Bairro</th>
                <th class="text-center">Cidade</th>
                <th class="text-center">End. Principal</th>
                <th class="text-center">Opções</th>
              </thead>
              <tbody>
                <?php $__currentLoopData = $consulta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="text-center"><?php echo e($item->contato->nome); ?></td>
                  <td class="text-center"><?php echo e($item->endereco); ?></td>
                  <td class="text-center"><?php echo e($item->numero); ?></td>
                  <td class="text-center"><?php echo e($item->bairro); ?></td>
                  <td class="text-center"><?php echo e($item->cidade); ?></td>
                  <td class="text-center"><?php echo e($item->principal == 1 ? 'Sim' : 'Não'); ?></td>
                  <td class="text-center">
                    <div class="btn-group">
                      <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Action
                      </button>
                      <div class="dropdown-menu">
                        <a class="dropdown-item" href="<?php echo e(route('endereco.edit', $item->id)); ?>">Alterar</a>
                        <a class="dropdown-item" href="<?php echo e($item->id); ?>" data-contid=<?php echo e($item->id); ?> data-target="#delete" data-toggle="modal">Remover</a>
                      </div>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
          <div class="row">
            <div class="col-md-10"><p>Mostrando <?php echo e($consulta->count()); ?> endereços de um total de <?php echo e($consulta->total()); ?></p></div>
            <div class="col-md-2"><?php echo e($consulta->links()); ?></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <?php echo $__env->make('pages.enderecos.modalExcluirEntrega', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src='https://cdnjs.com/libraries/jquery.mask'></script>
<script src='<?php echo e(asset('js/enderecos/entrega.js')); ?>'></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'Listagem de Endereços',
'class' => 'sidebar-mini',
'activePage' => 'localendereco',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/acptic24/public_html/resources/views/pages/enderecos/listagemEndereco.blade.php ENDPATH**/ ?>