<div class="content">
  <div class="row">
    <div class="form-group col-md-4">
      <label for="tipo">Tipo de Contato*</label>
      <select id="tipo" class="form-control" name="tipo">
        <option value="Cliente" >Cliente</option>
        <option value="Fornecedor" >Fornecedor</option>
      </select>
    </div>
  </div>
  
  <div class="row">
    <div class="col-md-12">
      <div class="form-group">
        <label for="nome">Nome Completo*</label>
        <input type="text" class="form-control" id="nome" name="nome" value="<?php echo e(isset($contato) ? $contato->nome : old('nome')); ?>" placeholder="Digite o nome completo" required>
        <?php echo $__env->make('alerts.feedback', ['field' => 'nome'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>      
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
          <label for="documento">Documento</label>
          <input type="text" class="form-control" id="documento" name="documento" value="<?php echo e(isset($contato) ? $contato->documento : old('documento')); ?>" placeholder="Ex. 000.000.000-00">
          <?php echo $__env->make('alerts.feedback', ['field' => 'documento'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
          <label for="telefone">Telefone*</label>
          <input type="text" class="form-control telefone" id="telefone" name="telefone" value="<?php echo e(isset($contato) ? $contato->telefone : old('telefone')); ?>" placeholder="Ex. (99) 99999-9999" required>
          <?php echo $__env->make('alerts.feedback', ['field' => 'telefone'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\wamp64\www\projetos\delivery\resources\views/pages/contatos/formContato.blade.php ENDPATH**/ ?>