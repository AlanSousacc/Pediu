<div class="input-group <?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
  <div class="input-group-prepend">
    <div class="input-group-text">
      <i class="now-ui-icons users_circle-08"></i>
    </div>
  </div>
  <input class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Nome Completo')); ?>" type="text" name="name" value="<?php echo e(isset($user) ? $user->name : old('name')); ?>" required autofocus>
  <?php if($errors->has('name')): ?>
    <span class="invalid-feedback" style="display: block;" role="alert">
      <strong><?php echo e($errors->first('name')); ?></strong>
    </span>
  <?php endif; ?>
</div>
<!--Begin input email -->
<div class="input-group <?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
  <div class="input-group-prepend">
    <div class="input-group-text">
      <i class="now-ui-icons ui-1_email-85"></i>
    </div>
  </div>
  <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Email')); ?>" type="email" name="email" value="<?php echo e(isset($user) ? $user->email : old('email')); ?>" required>
 </div>
 <?php if($errors->has('email')): ?>
    <span class="invalid-feedback" style="display: block;" role="alert">
        <strong><?php echo e($errors->first('email')); ?></strong>
    </span>
<?php endif; ?>
<!--Begin input user type-->

<!--Begin input password -->
<div class="input-group <?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
  <div class="input-group-prepend">
    <div class="input-group-text">
      <i class="now-ui-icons objects_key-25"></i>
    </div>
  </div>
  <input class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Senha')); ?>" type="password" name="password" required>
  <?php if($errors->has('password')): ?>
    <span class="invalid-feedback" style="display: block;" role="alert">
      <strong><?php echo e($errors->first('password')); ?></strong>
    </span>
  <?php endif; ?>
</div>
<!--Begin input confirm password -->
<div class="input-group">
  <div class="input-group-prepend">
    <div class="input-group-text">
      <i class="now-ui-icons objects_key-25"></i></i>
    </div>
  </div>
  <input class="form-control" placeholder="<?php echo e(__('Confirmação de Senha')); ?>" type="password" name="password_confirmation" required>
</div><?php /**PATH C:\wamp64\www\projetos\delivery\resources\views/users/formUsers.blade.php ENDPATH**/ ?>