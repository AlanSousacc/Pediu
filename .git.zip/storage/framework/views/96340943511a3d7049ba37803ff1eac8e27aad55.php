<div class="card-body">
  <div class="table-responsive" style="overflow: initial!important;">
    <table class="table">
      <thead class=" text-primary">
        <th class="text-center">Hora</th>
        <th class="text-center">Cliente</th>
        <th class="text-center">Sub.</th>
        <th class="text-center">Total</th>
        <th class="text-center">Desc.</th>
        <th class="text-center">Troco</th>
        <th class="text-center">status</th>
        <th class="text-center">Opções</th>
      </thead>
      <tbody>
        <?php $__currentLoopData = $consulta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td class="text-center"><?php echo e($item->created_at->format('H:i:s')); ?></td>
          <td class="text-center"><?php echo e($item->contato->nome); ?></td>
          <td class="text-center">R$ <?php echo e(number_format($item->subtotal, 2, ',', '.')); ?></td>
          <td class="text-center">R$ <?php echo e(number_format($item->total, 2, ',', '.')); ?></td>
          <td class="text-center">R$ <?php echo e(number_format($item->desconto, 2, ',', '.')); ?></td>
          <td class="text-center">R$ <?php echo e(number_format($item->valortroco, 2, ',', '.')); ?></td>
          <?php if($item->entregador_id != null): ?>
          <td class="text-center text-success">Entregue / A caminho</td>
          <?php else: ?>
          <td class="text-center text-warning">Aguard. Entregador</td>
          <?php endif; ?>
          
          <td class="text-center">
            <div class="btn-group">
              <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Action
              </button>
              <div class="dropdown-menu">
                <a class="dropdown-item" href="<?php echo e(route('pedido.detalhe', $item->id)); ?>"><i class="now-ui-icons files_paper"></i>Detalhar Pedido</a>
                <?php if($item->entregador_id == null): ?>
                <a class="dropdown-item" href="<?php echo e($item->id); ?>" 
                  data-pedidoid=<?php echo e($item->id); ?> 
                  data-target="#mudarStatus" 
                  data-statusentrega="<?php echo e($item->statusentrega); ?>" 
                  data-entregador_id="<?php echo e($item->entregador_id); ?>" 
                  data-valortroco="<?php echo e($item->valortroco); ?>" 
                  data-troco="<?php echo e($item->troco); ?>" 
                  data-toggle="modal"><i class="now-ui-icons shopping_delivery-fast"></i>Definir Entregador</a>
                  <a class="dropdown-item" href="<?php echo e(route('pedido.edit', $item->id)); ?>"><i class="now-ui-icons education_paper"></i>Alterar</a>
                  <a class="dropdown-item" href="<?php echo e($item->id); ?>" data-contid=<?php echo e($item->id); ?> data-target="#delete" data-toggle="modal"><i class="now-ui-icons ui-1_simple-remove"></i>Remover</a>
                  <?php endif; ?>
                </div>
              </div>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
          <tr>
            <td class="text-center" colspan="2"></td>
            <td class="text-center" style="font-weight:600">R$ <?php echo e(number_format($consulta->sum('subtotal'), 2, ',', '.')); ?></td>
            <td class="text-center" style="font-weight:600">R$ <?php echo e(number_format($consulta->sum('total'), 2, ',', '.')); ?></td>
            <td class="text-center" style="font-weight:600">R$ <?php echo e(number_format($consulta->sum('desconto'), 2, ',', '.')); ?></td>
            <td class="text-center" colspan="3"></td>
          </tr>
        </tfoot>
      </table>
    </div>
    <div class="row">
      <div class="col-md-10"><p>Mostrando <?php echo e($consulta->count()); ?> pedidos de um total de <?php echo e($consulta->total()); ?></p></div>
      <div class="col-md-2"><?php echo e($consulta->links()); ?></div>
    </div>
  </div><?php /**PATH C:\wamp64\www\projetos\delivery\resources\views/pages/pedidos/ListagemPedidosBase.blade.php ENDPATH**/ ?>