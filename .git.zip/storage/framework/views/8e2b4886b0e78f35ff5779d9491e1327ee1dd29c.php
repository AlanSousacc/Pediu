

<?php $__env->startSection('content'); ?>
<div class="col-md-3 offset-md-9 fixed-top mt-3" style="z-index: 9999;">
  <?php echo $__env->make('layouts.messages.master-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<div class="panel-header panel-header-sm">
</div>
<div class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card card-nav-tabs card-plain">
          <div class="card-header card-header-warning">
            <!-- colors: "header-primary", "header-info", "header-success", "header-warning", "header-danger" -->
            <div class="nav-tabs-navigation">
              <div class="nav-tabs-wrapper">
                <ul class="nav nav-tabs" data-tabs="tabs">
                  <li class="nav-item">
                    <a class="nav-link active" href="#valoresAbertos" data-toggle="tab">Em Aberto</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#valoresPagos" data-toggle="tab">Pagos</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="card-body">

            <div class="tab-content text-center">
              
              <div class="tab-pane active" id="valoresAbertos">
                <div class="card-header">
                  <h4 class="card-title text-left"> Movimentações em Abertas do Contato</h4>
                </div>
                <div class="table-responsive" style="overflow: initial!important;">
                  <table class="table">
                    <thead class=" text-primary">
                      <th class="text-center">#ID</th>
                      <th class="text-center">Data do Pedido</th>
                      <th class="text-center">Status</th>
                      <th class="text-center">Valor Total</th>
                      <th class="text-center">Recebido</th>
                      <th class="text-center">Restante</th>
                      <th class="text-center">Opções</th>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $movimentacao->where('status', 0)->where('contato_id', $contato->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td class="text-center"><?php echo e($item->id); ?></td>
                        <td class="text-center"><?php echo e($item->created_at->format('d/m/Y H:i:s')); ?></td>
                        <td class="text-center text-danger"><i class="ionicons ion-close-circled"></i></td>
                        <td class="text-center">R$ <?php echo e(number_format($item->valortotal, 2, ',', '.')); ?></td>
                        <td class="text-center">R$ <?php echo e(number_format($item->valorrecebido, 2, ',', '.')); ?></td>
                        <td class="text-center">R$ <?php echo e(number_format($item->valorpendente, 2, ',', '.')); ?></td>
                        <td class="text-center">
                          <div class="btn-group">
                            <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Action
                            </button>
                            <div class="dropdown-menu">
                              <a class="dropdown-item"
                                href="<?php echo e($item->id); ?>"
                                data-valtotal=<?php echo e($item->valortotal); ?> 
                                data-valorrecebido=<?php echo e($item->valorrecebido); ?> 
                                data-valorpendente=<?php echo e($item->valorpendente); ?> 
                                data-movimentacaoid=<?php echo e($item->id); ?> 
                                data-target="#receber" 
                                data-toggle="modal"><i class="ionicons ion-cash"></i> Receber</a>
                              <a class="dropdown-item" href="<?php echo e(route('pedido.detalhe', $item->pedido_id)); ?>"><i class="ionicons ion-ios-paper-outline"></i> Detalhar</a>
                            </div>
                          </div>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <div class="row">
                  <div class="col-md-10 text-left"><p>Mostrando <?php echo e($movimentacao->count()); ?> movimentações em abertas de um total de <?php echo e($movimentacao->total()); ?></p></div>
                  <div class="col-md-2"><?php echo e($movimentacao->links()); ?></div>
                </div>
              </div>
              

              
              <div class="tab-pane" id="valoresPagos">
                <div class="card-header">
                  <h4 class="card-title text-left"> Movimentações Pagas do Contato</h4>
                </div>
                <div class="table-responsive" style="overflow: initial!important;">
                  <table class="table">
                    <thead class=" text-primary">
                      <th class="text-center">#ID</th>
                      <th class="text-center">Data do Pedido</th>
                      <th class="text-center">Status</th>
                      <th class="text-center">Valor Total</th>
                      <th class="text-center">Recebido</th>
                      <th class="text-center">Opções</th>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $movimentacao->where('status', 1)->where('contato_id', $contato->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td class="text-center"><?php echo e($item->id); ?></td>
                        <td class="text-center"><?php echo e($item->created_at->format('d/m/Y H:i:s')); ?></td>
                        <td class="text-center text-success"><i class="ionicons ion-checkmark-circled"></i></td>
                        <td class="text-center">R$ <?php echo e(number_format($item->valortotal, 2, ',', '.')); ?></td>
                        <td class="text-center">R$ <?php echo e(number_format($item->valorrecebido, 2, ',', '.')); ?></td>
                        <td class="text-center">
                          <div class="btn-group">
                            <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Action
                            </button>
                            <div class="dropdown-menu">
                              <a class="dropdown-item" href="<?php echo e(route('pedido.detalhe', $item->pedido_id)); ?>"><i class="ionicons ion-ios-paper-outline"></i> Detalhar</a>
                            </div>
                          </div>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <div class="row">
                  <div class="col-md-10 text-left"><p>Mostrando <?php echo e($movimentacao->where('status', 1)->where('contato_id', $contato->id)->count()); ?> movimentações encerradas de um total de <?php echo e($movimentacao->total()); ?></p></div>
                  <div class="col-md-2"><?php echo e($movimentacao->links()); ?></div>
                </div>
              </div>
              
            </div>

          </div>
          
        </div>
      </div>
    </div>
  </div>
  
  <?php echo $__env->make('pages.contatos.modalReceber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src='<?php echo e(asset('js/contato/contato.js')); ?>'></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'Financeiro do Contatos',
'class' => 'sidebar-mini',
'activePage' => 'listagemfinanceirocontato',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\projetos\delivery\resources\views/pages/contatos/listagemFinanceiroContato.blade.php ENDPATH**/ ?>