<div class="sidebar" data-color="orange">
  <!--
    Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
  -->
  <div class="logo">
    <a href="<?php echo e(route('home')); ?>" class="simple-text logo-mini">
      <?php echo e(__('SF')); ?>

    </a>
    <a href="<?php echo e(route('home')); ?>" class="simple-text logo-normal">
      <?php echo e(__('Suzi Fiacadori')); ?>

    </a>
  </div>
  <div class="sidebar-wrapper" id="sidebar-wrapper">
    <ul class="nav">
      
      <li class="active">
        <a data-toggle="collapse" href="#pedidos">
          <i class="now-ui-icons shopping_shop" style="color: #f96332;"></i>
          <p style="color: #f96332;">
            <?php echo e(__("Pedidos")); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse <?php if($activePage == 'editarpedido' || $activePage == 'detalhepedido' || $activePage == 'novopedido' || $activePage == 'listagemPedidos'): ?> show <?php endif; ?>" id="pedidos">
          <ul class="nav">
            <li class="<?php if($activePage == 'novopedido'): ?> active <?php endif; ?>">
              <a href="<?php echo e(route('pedido.create')); ?>">
                <i class="now-ui-icons shopping_bag-16"></i>
                <p> <?php echo e(__("Novo Pedido")); ?> </p>
              </a>
            </li>
            <li class="<?php if($activePage == 'listagemPedidos'): ?> active <?php endif; ?>">
              <a href="<?php echo e(route('pedido.index')); ?>">
                <i class="ionicons ion-ios-list-outline"></i>
                <p> <?php echo e(__("Listagem")); ?> </p>
              </a>
            </li>
            <?php if($activePage == 'detalhepedido'): ?>
            <li class="<?php if($activePage == 'detalhepedido'): ?> active <?php endif; ?>">
              <a href="<?php echo e(route('pedido.detalhe', $item->id)); ?>">
                <i class="now-ui-icons files_paper"></i>
                <p> <?php echo e(__("Detalhe do Pedido")); ?> </p>
              </a>
            </li>
            <?php endif; ?>
            <?php if($activePage == 'editarpedido'): ?>
            <li class="<?php if($activePage == 'editarpedido'): ?> active <?php endif; ?>">
              <a href="#">
                <i class="ionicons ion-ios-compose-outline"></i>
                <p> <?php echo e(__("Editar Pedido")); ?> </p>
              </a>
            </li>
            <?php endif; ?>
          </ul>
        </div>
      </li>
      
      
      
      <li>
        <a data-toggle="collapse" href="#contatos">
          <i class="fa fa-user-friends"></i>
          <p>
            <?php echo e(__("Contatos")); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse <?php if($activePage == 'listagemfinanceirocontato' || $activePage == 'editarcontato' || $activePage == 'novocontato' || $activePage == 'listagemContato'): ?> show <?php endif; ?>" id="contatos">
          <ul class="nav">
            <li class="<?php if($activePage == 'novocontato'): ?> active <?php endif; ?>">
              <a href="<?php echo e(route('contato.create')); ?>">
                <i class="now-ui-icons ui-1_simple-add"></i>
                <p> <?php echo e(__("Novo")); ?> </p>
              </a>
            </li>
            <li class="<?php if($activePage == 'listagemContato'): ?> active <?php endif; ?>">
              <a href="<?php echo e(route('contato.index')); ?>">
                <i class="ionicons ion-ios-list-outline"></i>
                <p> <?php echo e(__("Listagem")); ?> </p>
              </a>
            </li>
            <?php if($activePage == 'editarcontato'): ?>
            <li class="<?php if($activePage == 'editarcontato'): ?> active <?php endif; ?>">
              <a href="<?php echo e(route('contato.index')); ?>">
                <i class="ionicons ion-ios-compose-outline"></i>
                <p> <?php echo e(__("Editar Contato")); ?> </p>
              </a>
            </li>
            <?php endif; ?>
            <?php if($activePage == 'listagemfinanceirocontato'): ?>
            <li class="<?php if($activePage == 'listagemfinanceirocontato'): ?> active <?php endif; ?>">
              <a href="#">
                <i class="ionicons ion-social-usd-outline"></i>
                <p> <?php echo e(__("Financeiro Contato")); ?> </p>
              </a>
            </li>
            <?php endif; ?>
          </ul>
        </div>
      </li>
      
      
      
      <li>
        <a data-toggle="collapse" href="#entregadores">
          <i class="now-ui-icons shopping_delivery-fast"></i>
          <p>
            <?php echo e(__("Entregadores")); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse <?php if($activePage == 'editarentregador' || $activePage == 'listagemEntregador' || $activePage == 'novoentregador'): ?> show <?php endif; ?>" id="entregadores">
          <ul class="nav">
            <li class="<?php if($activePage == 'novoentregador'): ?> active <?php endif; ?>">
              <a href="<?php echo e(route('entregador.create')); ?>">
                <i class="now-ui-icons ui-1_simple-add"></i>
                <p> <?php echo e(__("Novo")); ?> </p>
              </a>
            </li>
            <li class="<?php if($activePage == 'listagemEntregador'): ?> active <?php endif; ?>">
              <a href="<?php echo e(route('entregador.index')); ?>">
                <i class="ionicons ion-ios-list-outline"></i>
                <p> <?php echo e(__("Listagem")); ?> </p>
              </a>
            </li>
            <?php if($activePage == 'editarentregador'): ?>
            <li class="<?php if($activePage == 'editarentregador'): ?> active <?php endif; ?>">
              <a href="<?php echo e(route('contato.index')); ?>">
                <i class="ionicons ion-ios-compose-outline"></i>
                <p> <?php echo e(__("Editar Entregador")); ?> </p>
              </a>
            </li>
            <?php endif; ?>
          </ul>
        </div>
      </li>
      
      
      
      <li>
        <a data-toggle="collapse" href="#localendereco">
          <i class="now-ui-icons location_pin"></i>
          <p>
            <?php echo e(__("Local de entrega")); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse <?php if($activePage == 'editarendereco' || $activePage == 'localendereco'): ?> show <?php endif; ?>" id="localendereco">
          <ul class="nav">
            <li class="<?php if($activePage == 'localendereco'): ?> active <?php endif; ?>">
              <a href="<?php echo e(route('endereco.index')); ?>">
                <i class="ionicons ion-ios-list-outline"></i>
                <p> <?php echo e(__("Listagem")); ?> </p>
              </a>
            </li>
            <?php if($activePage == 'editarendereco'): ?>
            <li class="<?php if($activePage == 'editarendereco'): ?> active <?php endif; ?>">
              <a href="#">
                <i class="ionicons ion-ios-compose-outline"></i>
                <p> <?php echo e(__("Editar Endereço")); ?> </p>
              </a>
            </li>
            <?php endif; ?>
          </ul>
        </div>
      </li>
      
      
      
      <li>
        <a data-toggle="collapse" href="#produtos">
          <i class="fa fa-box-open"></i>
          <p>
            <?php echo e(__("Produtos")); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse <?php if($activePage == 'editarproduto' || $activePage == 'listagemProdutos' || $activePage == 'novoproduto'): ?> show <?php endif; ?>" id="produtos">
          <ul class="nav">
            <li class="<?php if($activePage == 'novoproduto'): ?> active <?php endif; ?>">
              <a href="<?php echo e(route('produto.create')); ?>">
                <i class="now-ui-icons ui-1_simple-add"></i>
                <p> <?php echo e(__("Novo")); ?> </p>
              </a>
            </li>
            <li class="<?php if($activePage == 'listagemProdutos'): ?> active <?php endif; ?>">
              <a href="<?php echo e(route('produto.index')); ?>">
                <i class="ionicons ion-ios-list-outline"></i>
                <p> <?php echo e(__("Listagem")); ?> </p>
              </a>
            </li>
            <?php if($activePage == 'editarproduto'): ?>
            <li class="<?php if($activePage == 'editarproduto'): ?> active <?php endif; ?>">
              <a href="<?php echo e(route('produto.index')); ?>">
                <i class="ionicons ion-ios-compose-outline"></i>
                <p> <?php echo e(__("Editar Produto")); ?> </p>
              </a>
            </li>
            <?php endif; ?>
          </ul>
        </div>
      </li>
      
      
      
      <li>
        <a data-toggle="collapse" href="#usuarios">
          <i class="now-ui-icons users_single-02"></i>
          <p>
            <?php echo e(__("Usuários")); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse <?php if($activePage == 'editarusuario' || $activePage == 'listagemusuario' || $activePage == 'novousuario'): ?> show <?php endif; ?>" id="usuarios">
          <ul class="nav">
            <li class="<?php if($activePage == 'novousuario'): ?> active <?php endif; ?>">
              <a href="<?php echo e(route('register')); ?>">
                <i class="now-ui-icons ui-1_simple-add"></i>
                <p> <?php echo e(__("Novo")); ?> </p>
              </a>
            </li>
            <li class="<?php if($activePage == 'listagemusuario'): ?> active <?php endif; ?>">
              <a href="<?php echo e(route('user.index')); ?>">
                <i class="ionicons ion-ios-list-outline"></i>
                <p> <?php echo e(__("Listagem")); ?> </p>
              </a>
            </li>
            <?php if($activePage == 'editarusuario'): ?>
            <li class="<?php if($activePage == 'editarusuario'): ?> active <?php endif; ?>">
              <a href="#">
                <i class="ionicons ion-ios-list-outline"></i>
                <p> <?php echo e(__("Editar Usuário")); ?> </p>
              </a>
            </li>
            <?php endif; ?>
          </ul>
        </div>
      </li>
      
    </ul>
  </div>
</div><?php /**PATH C:\wamp64\www\projetos\delivery\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>