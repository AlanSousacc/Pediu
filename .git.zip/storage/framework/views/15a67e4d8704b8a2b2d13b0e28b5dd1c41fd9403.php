<div class="content">
  <div class="row">
    <div class="form-group col-md-4">
      <label for="status">Status*</label>
      <select id="status" class="form-control" name="status">
        <option value="1" >Ativo</option>
        <option value="0" >Inativo</option>
      </select>
    </div>
  </div>
  
  <div class="row">
    <div class="col-md-4">
      <div class="form-group">
        <label for="nome">Nome*</label>
        <input type="text" class="form-control" id="nome" name="nome" value="<?php echo e(isset($entregador) ? $entregador->nome : old('nome')); ?>" placeholder="Nome do Entregador" required>
        <?php echo $__env->make('alerts.feedback', ['field' => 'nome'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
    <div class="col-md-4">
      <div class="form-group">
        <label for="endereco">Endereço</label>
        <input type="text" class="form-control" id="endereco" name="endereco" value="<?php echo e(isset($entregador) ? $entregador->endereco : old('endereco')); ?>" placeholder="Endereço do entregador">
        <?php echo $__env->make('alerts.feedback', ['field' => 'endereco'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
    <div class="col-md-4">
      <div class="form-group">
        <label for="numero">Número</label>
        <input type="text" class="form-control" id="numero" name="numero" value="<?php echo e(isset($entregador) ? $entregador->numero : old('numero')); ?>" placeholder="000">
        <?php echo $__env->make('alerts.feedback', ['field' => 'numero'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
    
  </div>
  
  <div class="row">
    <div class="col-md-4">
      <div class="form-group">
        <label for="cidade">Cidade</label>
        <input type="text" class="form-control" id="cidade" name="cidade" value="<?php echo e(isset($entregador) ? $entregador->cidade : old('cidade')); ?>" placeholder="Cidade.">
        <?php echo $__env->make('alerts.feedback', ['field' => 'cidade'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
    <div class="col-md-4">
      <div class="form-group">
        <label for="bairro">Bairro</label>
        <input type="text" class="form-control bairro" id="bairro" name="bairro" value="<?php echo e(isset($entregador) ? $entregador->bairro : old('bairro')); ?>" placeholder="Bairro">
        <?php echo $__env->make('alerts.feedback', ['field' => 'bairro'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
    <div class="col-md-4">
      <div class="form-group">
        <label for="telefone">Telefone*</label>
        <input type="text" class="form-control" id="telefone" name="telefone" value="<?php echo e(isset($entregador) ? $entregador->telefone : old('telefone')); ?>" placeholder="Ex. (99) 99999-9999)" required>
        <?php echo $__env->make('alerts.feedback', ['field' => 'telefone'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
  </div>
  
  <div class="row">
    <div class="col-md-4">
      <div class="form-group">
        <label for="cep">CEP</label>
        <input type="text" class="form-control" id="cep" name="cep" value="<?php echo e(isset($entregador) ? $entregador->cep : old('cep')); ?>" placeholder="Ex. 00000-000">
        <?php echo $__env->make('alerts.feedback', ['field' => 'cep'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
    <div class="form-group col-md-4">
      <label for="veiculo">Vaículo*</label>
      <select id="veiculo" class="form-control" name="veiculo" required>
        <option value="Carro">Carro</option>
        <option value="Moto">Moto</option>
        <option value="Bicicleta">Bicicleta</option>
        <option value="Nenhum">Nenhum</option>
      </select>
    </div>
    <div class="col-md-4">
      <div class="form-group">
        <label for="placa">Placa Veículo</label>
        <input type="text" class="form-control" id="placa" name="placa" value="<?php echo e(isset($entregador) ? $entregador->placa : old('placa')); ?>" placeholder="Placa do Veículo">
        <?php echo $__env->make('alerts.feedback', ['field' => 'placa'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
  </div>
</div><?php /**PATH /home3/acptic24/public_html/resources/views/pages/entregadores/formEntregador.blade.php ENDPATH**/ ?>