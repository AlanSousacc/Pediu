<footer class="footer">
  <div class=" container-fluid ">
    
    
  </div>
</footer><?php /**PATH C:\wamp64\www\projetos\delivery\resources\views/layouts/footer.blade.php ENDPATH**/ ?>