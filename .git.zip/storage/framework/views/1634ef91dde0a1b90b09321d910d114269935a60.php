

<?php $__env->startSection('content'); ?>
<div class="col-md-3 offset-md-9 fixed-top mt-3" style="z-index: 9999;">
  <?php echo $__env->make('layouts.messages.master-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<div class="panel-header panel-header-sm">
</div>
<div class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title"> Produtos</h4>
        </div>
        <div class="card-body">
          <div class="table-responsive" style="overflow: initial!important;">
            <table class="table">
              <thead class=" text-primary">
                <th class="text-center">#ID</th>
                <th class="text-center">Descrição</th>
                <th class="text-center">Pr. Custo</th>
                <th class="text-center">Pr. Venda</th>
                <th class="text-center">Tipo</th>
                <th class="text-center">Opções</th>
              </thead>
              <tbody>
                <?php $__currentLoopData = $consulta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="text-center"><?php echo e($item->id); ?></td>
                  <td class="text-center"><?php echo e($item->descricao); ?></td>
                  <td class="text-center">R$ <?php echo e(number_format($item->precocusto, 2, ',', '.')); ?></td>
                  <td class="text-center">R$ <?php echo e(number_format($item->precovenda, 2, ',', '.')); ?></td>
                  <td class="text-center"><?php echo e($item->tipo); ?></td>
                  <td class="text-center">
                    <div class="btn-group">
                      <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Action
                      </button>
                      <div class="dropdown-menu">
                        <a class="dropdown-item" href="<?php echo e(route('produto.edit', $item->id)); ?>">Alterar</a>
                        <a class="dropdown-item" href="<?php echo e($item->id); ?>" data-contid=<?php echo e($item->id); ?> data-target="#delete" data-toggle="modal">Remover</a>
                      </div>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
          <div class="row">
            <div class="col-md-10"><p>Mostrando <?php echo e($consulta->count()); ?> produtos de um total de <?php echo e($consulta->total()); ?></p></div>
            <div class="col-md-2"><?php echo e($consulta->links()); ?></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <?php echo $__env->make('pages.produtos.modalExcluirProduto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>

<script src='<?php echo e(asset('js/produtos/produtos.js')); ?>'></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'Listagem de Produtos',
'class' => 'sidebar-mini',
'activePage' => 'listagemProdutos',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\projetos\delivery\resources\views/pages/produtos/listagemProduto.blade.php ENDPATH**/ ?>