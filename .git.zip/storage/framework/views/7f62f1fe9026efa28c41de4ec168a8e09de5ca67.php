
<?php $__env->startSection('content'); ?>
<div class="col-md-3 offset-md-9 fixed-top mt-3" style="z-index: 9999;">
  <?php echo $__env->make('layouts.messages.master-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<div class="panel-header panel-header-sm">
</div>
<div class="content">
  <div class="row" >
    <div class="col-md-10 offset-1">
      <div class="card">
        <div class="card-header">
          <h5 class="title"><?php echo e(__("Detalhes do Pedido")); ?></h5>
        </div>
        <div class="card-body details">
          <div class="card card-nav-tabs card-plain">
            <div class="card-header card-header-primary">
              <!-- colors: "header-primary", "header-info", "header-success", "header-warning", "header-danger" -->
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class="nav-link active" href="#detalhePedido" data-toggle="tab">Detalhes Pedido</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#itensPedido" data-toggle="tab">Itens do Pedido</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#detalhesPagamento" data-toggle="tab">Detalhes do Pagamento</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="card-body ">
              <div class="tab-content">
                
                <div class="tab-pane active" id="detalhePedido">
                  <div class="row">
                    <div class="col-md-2">
                      <div class="form-group">
                        <label class="col ml-2">#ID</label>
                        <input type="text" disabled class="form-control text-center" value="<?php echo e(isset($pedido) ? $pedido->id : ''); ?>" >
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group">
                        <label class="col ml-2">Data e Hora</label>
                        <input type="text" disabled class="form-control"value="<?php echo e(isset($pedido) ? $pedido->created_at->format('d/m/Y H:i:s') : ''); ?>">
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group">
                        <label class="col ml-2">Status do Pedido</label>
                        <?php if($pedido->statusentrega == 0): ?>
                        <input type="text" class="form-control text-warning" value="Pedido Processado"> 
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  
                  
                  <div class="row">
                    <div class="col-md-9">
                      <div class="form-group">
                        <label class="col ml-2">Nome Completo</label>
                        <input type="text" disabled class="form-control" value="<?php echo e(isset($pedido) ? $pedido->contato->nome : ''); ?>" >
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group">
                        <label class="col ml-2">Telefone</label>
                        <input type="text" disabled class="form-control" value="<?php echo e(isset($pedido) ? $pedido->contato->telefone : ''); ?>" >
                      </div>
                    </div>
                  </div>
                  
                  
                  
                  <div class="row">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label class="col ml-2">Endereço</label>
                        <input type="text" disabled class="form-control" value="<?php echo e(isset($pedido) ? $pedido->endereco->endereco : ''); ?>" >
                      </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label class="col ml-2">Número</label>
                        <input type="text" disabled class="form-control"ora" value="<?php echo e(isset($pedido) ? $pedido->endereco->numero : ''); ?>" >
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group">
                        <label class="col ml-2">Bairro</label>
                        <input type="text" disabled class="form-control" value="<?php echo e(isset($pedido) ? $pedido->endereco->bairro : ''); ?>" >
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group">
                        <label class="col ml-2 text-left">Cidade</label>
                        <input type="text" disabled class="form-control" value="<?php echo e(isset($pedido) ? $pedido->endereco->cidade : ''); ?>" >
                      </div>
                    </div>
                  </div>
                  
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label class="col ml-2">Observação</label>
                        <input type="text" disabled class="form-control" value="<?php echo e(isset($pedido) ? $pedido->endereco->observacao : ''); ?>" >
                      </div>
                    </div>
                  </div>
                </div>
                
                
                
                <div class="tab-pane" id="itensPedido">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="table-responsive" style="overflow: initial!important;">
                        <table class="table">
                          <thead class=" text-primary">
                            <th class="text-center">#ID</th>
                            <th class="text-center">Descrição</th>
                            <th class="text-center">Qtde</th>
                            <th class="text-center">Vlr. Unitário</th>
                            <th class="text-center">Vlr. Total</th>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = $pedido->produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td class="text-center"><?php echo e($item->id); ?></td>
                              <td class="text-center"><?php echo e($item->descricao); ?>

                                <?php if($item->pivot->obsitem != null): ?>
                                <br><small class="obs-item"><?php echo e($item->pivot->obsitem); ?></small></td>
                                <?php endif; ?>
                              </td>
                              <td class="text-center"><?php echo e($item->pivot->qtde); ?></td>
                              <td class="text-center">R$ <?php echo e(number_format($item->pivot->prvenda, 2, ',', '.')); ?></td>
                              <td class="text-center">R$ <?php echo e(number_format($item->pivot->prvenda * $item->pivot->qtde, 2, ',', '.')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
                
                
                <div class="tab-pane" id="detalhesPagamento">
                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group">
                        <label class="col ml-2">Forma de Pagamento</label>
                        <input type="text" disabled class="form-control" value="<?php echo e(isset($pedido) ? $pedido->forma_pagamento : ''); ?>" >
                      </div>
                    </div>
                    
                    <div class="col-md-3">
                      <label class="col ml-2">Desconto</label>
                      <div class="input-group col">
                        <div class="input-group-prepend">
                          <span class="input-group-text">R$</span>
                        </div>
                        <input type="text" disabled class="form-control text-center" value="<?php echo e(number_format(isset($pedido) ? $pedido->desconto : '', 2, ',', '.')); ?>">
                      </div>
                    </div>
                    
                    <div class="col-md-3">
                      <label class="col ml-2">Sub Total</label>
                      <div class="input-group col">
                        <div class="input-group-prepend">
                          <span class="input-group-text">R$</span>
                        </div>
                        <input type="text" disabled class="form-control text-center" value="<?php echo e(number_format(isset($pedido) ? $pedido->total : '', 2, ',', '.')); ?>">
                      </div>
                    </div>

                    <div class="col-md-3">
                      <label class="col ml-2">Total</label>
                      <div class="input-group col">
                        <div class="input-group-prepend">
                          <span class="input-group-text">R$</span>
                        </div>
                        <input type="text" disabled class="form-control text-center" value="<?php echo e(number_format(isset($pedido) ? $pedido->total - $pedido->desconto : '', 2, ',', '.')); ?>">
                      </div>
                    </div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
          
        </div>
        <div class="card-footer text-right">
          <a href="<?php echo e(route('imprimir.pedido', $pedido->id)); ?>" target="_blank" class="btn btn-success btn-round"><i class="ionicons ion-printer"></i> Imprimir Pedido</a>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src='<?php echo e(asset('js/pedidos/pedidos.js')); ?>'></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'Detalhes do pedido',
'class' => 'sidebar-mini',
'activePage' => 'detalhepedido',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\projetos\delivery\resources\views/pages/pedidos/detalhePedido.blade.php ENDPATH**/ ?>