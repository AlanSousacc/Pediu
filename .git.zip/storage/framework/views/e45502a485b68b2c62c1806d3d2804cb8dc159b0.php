<div class="row">
  <div class="form-group col-md-12">
    <p class="h5 text-center">Pedido Processado, aguardando entregador</p>
  </div>
</div>



<div class="row">
  <div class="form-group col-md-12">
    <label for="entregador_id" class=" ml-3">Listagem de Entregadores</label>
    <select id="entregador_id" class="form-control col" name="entregador_id">
      <?php $__currentLoopData = $entregador; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($item->id); ?>" <?php echo e((old('entregador_id') == $item->id ) ? 'selected' : ''); ?> ><?php echo e($item->nome); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
</div>

<div class="row">
  <div class="form-group col-md-12 troco-modal">
    <label for="troco" class="col ml-3">Troco</label>
    <div class="input-group">
      <div class="input-group-prepend">
        <span class="input-group-text">R$</span>
      </div>
      <input type="text" value="0" name="troco" class="form-control text-center troco-modal-input">
    </div>
  </div>
</div><?php /**PATH C:\wamp64\www\projetos\delivery\resources\views/pages/pedidos/formStatusEntregador.blade.php ENDPATH**/ ?>