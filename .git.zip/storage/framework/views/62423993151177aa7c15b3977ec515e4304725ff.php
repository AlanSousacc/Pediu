<div class="content">
  <div class="row">
    <div class="form-group col-md-4">
      <label for="status">Status*</label>
      <select id="status" class="form-control" name="status">
        <option value="1" >Ativo</option>
        <option value="0" >Inativo</option>
      </select>
    </div>
    <div class="form-group col-md-4">
      <label for="principal">Endereço principal?*</label>
      <select id="principal" class="form-control" name="principal">
        <option value="1" <?php if(isset($entrega->principal) && $entrega->principal == 1): ?> selected <?php endif; ?> >Sim</option>
        <option value="0" <?php if(isset($entrega->principal) && $entrega->principal == 0): ?> selected <?php endif; ?> >Não</option>
      </select>
    </div>
  </div>
  
  <div class="row">
    <div class="col-md-4">
      <div class="form-group">
        <label for="endereco">Endereço*</label>
        <input type="text" class="form-control" id="endereco" name="endereco" value="<?php echo e(isset($entrega) ? $entrega->endereco : old('endereco')); ?>" placeholder="Rua:..." required>
        <?php echo $__env->make('alerts.feedback', ['field' => 'endereco'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
    <div class="col-md-4">
      <div class="form-group">
        <label for="numero">Número*</label>
        <input type="text" class="form-control" id="numero" name="numero" value="<?php echo e(isset($entrega) ? $entrega->numero : old('numero')); ?>" placeholder="000" required>
        <?php echo $__env->make('alerts.feedback', ['field' => 'numero'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
    <div class="col-md-4">
      <div class="form-group">
        <label for="bairro">Bairro</label>
        <input type="text" class="form-control" id="bairro" name="bairro" value="<?php echo e(isset($entrega) ? $entrega->bairro : old('bairro')); ?>" placeholder="Bairro">
        <?php echo $__env->make('alerts.feedback', ['field' => 'bairro'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
    
  </div>
  
  <div class="row">
    <div class="col-md-4">
      <div class="form-group">
        <label for="cidade">Cidade</label>
        <input type="text" class="form-control" id="cidade" name="cidade" value="<?php echo e(isset($entrega) ? $entrega->cidade : old('cidade')); ?>" placeholder="Cidade.">
        <?php echo $__env->make('alerts.feedback', ['field' => 'cidade'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
    <div class="col-md-4">
      <div class="form-group">
        <label for="cep">CEP</label>
        <input type="text" class="form-control" id="cep" name="cep" value="<?php echo e(isset($entrega) ? $entrega->cep : old('cep')); ?>" placeholder="Ex. 00000-000">
        <?php echo $__env->make('alerts.feedback', ['field' => 'cep'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
    <div class="col-md-4">
      <div class="form-group">
        <label for="telefone_entrega">Telefone Entrega</label>
        <input type="text" class="form-control telefone_entrega" id="telefone_entrega" name="telefone_entrega" value="<?php echo e(isset($entrega) ? $entrega->telefone_entrega : old('telefone_entrega')); ?>" placeholder="Ex. (99) 99999-9999">
        <?php echo $__env->make('alerts.feedback', ['field' => 'telefone_entrega'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
  </div>
  
  <div class="row">
    <div class="col-md-12">
      <div class="form-group">
        <label for="observacao">Observação</label>
        <input type="text" class="form-control" id="observacao" name="observacao" value="<?php echo e(isset($entrega) ? $entrega->observacao : old('observacao')); ?>" placeholder="Observação, ponto de referência...">
        <?php echo $__env->make('alerts.feedback', ['field' => 'observacao'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>
  </div>
</div><?php /**PATH /home3/acptic24/public_html/resources/views/pages/enderecos/formEndereco.blade.php ENDPATH**/ ?>