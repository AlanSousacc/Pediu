<?php if($errors->any()): ?>
<div class="alert alert-danger alert-with-icon" data-notify="container">
	<button type="button" aria-hidden="true" data-dismiss="alert" class="close">
		<i class="now-ui-icons ui-1_simple-remove"></i>
	</button>
	<span data-notify="icon" class="now-ui-icons travel_info"></span>
	<ul>
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li><?php echo e($error); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</div>
<?php endif; ?>

<?php if(\Session::has('success')): ?>
<div class="alert alert-success alert-with-icon" data-notify="container">
	<button type="button" aria-hidden="true" data-dismiss="alert" class="close">
		<i class="now-ui-icons ui-1_simple-remove"></i>
	</button>
	<span data-notify="icon" class="now-ui-icons ui-1_check"></span>
	<span data-notify="message"><?php echo e(\Session::get('success')); ?></span>
</div>
<?php elseif(\Session::has('error')): ?>
<div class="alert alert-danger alert-with-icon" data-notify="container">
	<button type="button" aria-hidden="true" data-dismiss="alert" class="close">
		<i class="now-ui-icons ui-1_simple-remove"></i>
	</button>
	<span data-notify="icon" class="now-ui-icons travel_info"></span>
	<span data-notify="message"><?php echo e(\Session::get('error')); ?></span>
</div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\projetos\delivery\resources\views/layouts/messages/master-message.blade.php ENDPATH**/ ?>