<?php $__env->startSection('content'); ?>
<div class="col-md-3 offset-md-9 fixed-top mt-3" style="z-index: 9999;">
  <?php echo $__env->make('layouts.messages.master-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<div class="panel-header panel-header-sm">
</div>
<div class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h5 class="title"><?php echo e(__(" Editar Contato")); ?></h5>
        </div>
        <div class="card-body">
				<form action="<?php echo e(route('contato.update', $contato->id)); ?>" method="post" autocomplete="off" enctype="multipart/form-data">
					<input type="hidden" name="_method" value="PUT">
          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
          <?php echo csrf_field(); ?>
					<?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<?php echo $__env->make('pages.contatos.formContato', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<h5 class="title"><?php echo e(__(" Endereço")); ?></h5>
					<?php echo $__env->make('pages.enderecos.formEndereco', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<div class="card-footer ">
						<button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Salvar Alterações')); ?></button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
</div>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>

<script src='<?php echo e(asset('js/contato/contato.js')); ?>'></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', [
'namePage' => 'editar contato',
'class' => 'sidebar-mini',
'activePage' => 'editarcontato',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/acptic24/public_html/resources/views/pages/contatos/editar.blade.php ENDPATH**/ ?>