<?php $__env->startSection('content'); ?>
<div class="col-md-3 offset-md-9 fixed-top mt-3" style="z-index: 9999;">
  <?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<div class="panel-header panel-header-sm">
</div>
<div class="content">
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <h5 class="title"><?php echo e(__(" Editar Meu Perfil")); ?></h5>
        </div>
        <div class="card-body">
          <form method="post" action="<?php echo e(route('profile.update')); ?>" autocomplete="off"
          enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
          <div class="row">
          </div>
          <div class="row">
            <div class="col-md-7 pr-1">
              <div class="form-group">
                <label><?php echo e(__(" Nome Completo")); ?></label>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name', auth()->user()->name)); ?>">
                <?php echo $__env->make('alerts.feedback', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-7 pr-1">
              <div class="form-group">
                <label for="exampleInputEmail1"><?php echo e(__(" Endereço de Email")); ?></label>
                <input type="email" name="email" class="form-control" placeholder="Email" value="<?php echo e(old('email', auth()->user()->email)); ?>">
                <?php echo $__env->make('alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
            </div>
          </div>
          <div class="card-footer ">
            <button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Salvar Perfil')); ?></button>
          </div>
          <hr class="half-rule"/>
        </form>
      </div>
      <div class="card-header">
        <h5 class="title"><?php echo e(__("Senha")); ?></h5>
      </div>
      <div class="card-body">
        <form method="post" action="<?php echo e(route('profile.password')); ?>" autocomplete="off">
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
          <?php echo $__env->make('alerts.success', ['key' => 'password_status'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="row">
            <div class="col-md-7 pr-1">
              <div class="form-group ">
                <label><?php echo e(__(" Senha Atual")); ?></label>
                <input class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="old_password" placeholder="<?php echo e(__('Senha Atual')); ?>" type="password"  required>
                <?php echo $__env->make('alerts.feedback', ['field' => 'old_password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-7 pr-1">
              <div class="form-group ">
                <label><?php echo e(__(" Nova Senha")); ?></label>
                <input class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Preencha a nova senha')); ?>" type="password" name="password" required>
                <?php echo $__env->make('alerts.feedback', ['field' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-7 pr-1">
              <div class="form-group ">
                <label><?php echo e(__(" Confirmação de Senha")); ?></label>
                <input class="form-control" placeholder="<?php echo e(__('Informe a senha digitada anteriormente')); ?>" type="password" name="password_confirmation" required>
              </div>
            </div>
          </div>
          <div class="card-footer ">
            <button type="submit" class="btn btn-primary btn-round "><?php echo e(__('Alterar Senha')); ?></button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card card-user">
      <div class="image">
        <img src="<?php echo e(asset('assets')); ?>/img/bg5.jpg" alt="...">
      </div>
      <div class="card-body">
        <div class="author">
          <a href="#">
            <img class="avatar border-gray" src="<?php echo e(asset('assets')); ?>/img/default-avatar.png" alt="...">
            <h5 class="title"><?php echo e(auth()->user()->name); ?></h5>
          </a>
          <p class="description">
            <?php echo e(auth()->user()->email); ?>

          </p>
          <p class="description">
            Data Criação: <?php echo e((auth()->user()->created_at)->format('d/m/Y H:i:s')); ?>

          </p>
          <p class="description">
            Ultima Alteração: <?php echo e((auth()->user()->updated_at)->format('d/m/Y H:i:s')); ?>

          </p>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', [
'class' => 'sidebar-mini ',
'namePage' => 'Perfil de Usuário',
'activePage' => 'profile',
'activeNav' => '',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\projetos\delivery\resources\views/profile/edit.blade.php ENDPATH**/ ?>