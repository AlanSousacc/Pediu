<div class="card-body">
  <div class="table-responsive" style="overflow: initial!important;">
    <table class="table">
      <thead class=" text-primary">
        <th class="text-center">#PEDIDO</th>
        <th class="text-center">Nome</th>
        <th class="text-center">Total Pedido(A)</th>
        <th class="text-center">Troco(B)</th>
        <th class="text-center">Total A+B</th>
        <th class="text-center">Baixado</th>
        <th class="text-center">Opções</th>
      </thead>
      <tbody>
        <?php $__currentLoopData = $consulta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td class="text-center"><?php echo e($item->id); ?></td>
          <td class="text-center"><?php echo e(!isset($item->entregador->nome) ? 'ENTREGADOR NÃO ATRIBUIDO!' : $item->entregador->nome); ?></td>
          <td class="text-center">R$ <?php echo e(number_format($item->total - $item->desconto, 2, ',', '.')); ?></td>
          <td class="text-center">R$ <?php echo e(number_format($item->valortroco, 2, ',', '.')); ?></td>
          <td class="text-center">R$ <?php echo e(number_format($item->subtotal + $item->valortroco, 2, ',', '.')); ?></td>
          <?php if($movimentacao->where('pedido_id', $item->id)->first()->status == 0): ?>
          <td class="text-center"><i class="ionicons ion-close-circled text-danger" id="tooltip" data-toggle="tooltip" data-placement="top" title="Só será baixado esta movimentação ao receber na Conta do Cliente"></i></td>
          <?php else: ?>
          <td class="text-center"><i class="ionicons ion-checkmark-circled text-success" id="tooltip" data-toggle="tooltip" data-placement="top" title="Movimentação baixada com sucesso!"></i></td>
          <?php endif; ?>
          <?php if($movimentacao->where('pedido_id', $item->id)->first()->status != 1): ?>
          <?php if($item->forma_pagamento != "Conta do Cliente"): ?>
          <td class="text-center"><a href="<?php echo e($item->id); ?>"
            data-contid=<?php echo e($item->id); ?>

            data-total=<?php echo e($item->subtotal + $item->valortroco); ?>

            data-entregador="<?php echo e(!isset($item->entregador->nome) ? 'ENTREGADOR NÃO ATRIBUIDO!' : $item->entregador->nome); ?>" data-target="#baixar" data-toggle="modal"><i class="fa fa-donate"></i> Receber</a></td>
            <?php else: ?>
            <td class="text-center text-warning"><i class="now-ui-icons travel_info" id="tooltip" data-toggle="tooltip" data-placement="top" title="O pedido foi lançado na Conta do Cliente"></i> Conta do Cliente</td>
            <?php endif; ?>
            <?php else: ?>
            <td class="text-center text-success"><i class="now-ui-icons ui-2_like" id="tooltip" data-toggle="tooltip" data-placement="top" title="Este pedido foi recebido do Entregador"></i> Concluído</td>
            <?php endif; ?>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <div class="row">
      <div class="col-md-10"><p>Mostrando <?php echo e($consulta->count()); ?> entregadores de um total de <?php echo e($consulta->total()); ?></p></div>
      <div class="col-md-2"><?php echo e($consulta->links()); ?></div>
    </div>
  </div><?php /**PATH C:\wamp64\www\projetos\delivery\resources\views/pages/entregadores/listagemPedidosEntregadores.blade.php ENDPATH**/ ?>