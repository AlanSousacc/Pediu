<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <title>Impressão do pedido {{$pedido->id}}</title>
</head>
<style>
  .header-pedido{
    text-align: center;
    width: 100%;
    display: inline;
  }
  .details{
    width: 100%;
  }
  .pedido{
    width: 100%;
  }
  .itens{
    width: 100%;
    display: block;
  }
  .logo-container img{
    width: 100%;
    max-width: 80px;
    text-align: center;
    margin: 0 0 10px 50px 
  }
</style>
<body>
  <div class="details">
    <div class="logo-container">
      <img src="{{ asset('assets/img/logo.png') }}" alt="">
    </div>
    <div class="pedido">
      Data e Hora: {{$pedido->created_at->format('d/m/Y H:i:s')}} <br>
    </div>
    <div class="cliente">
      <h5>Dados do cliente</h5>
      Nome: {{$pedido->contato->nome}}<br>
      Endereço: {{$pedido->endereco->endereco}}; Nº {{$pedido->endereco->numero}}<br>
      Bairro: {{$pedido->endereco->bairro}}; Tel: {{$pedido->contato->telefone}}
      <hr>
    </div>
    <div class="itens">
      <h5>Detalhes dos Itens</h5>
      <p style="text-align: center">Descrição - Obs - Qtde - Unit - Total</p>
      <hr>
      @foreach ($pedido->produtos as $item)
      <p style="text-align: center">
        {{$item->descricao}} - 
        {{$item->pivot->obsitem != null ? $item->pivot->obsitem : 'Sem Obs'}} - 
        {{$item->pivot->qtde}} - 
        R$ {{number_format($item->pivot->prvenda, 2, ',', '.')}} - 
        R$ {{number_format($item->pivot->prvenda * $item->pivot->qtde, 2, ',', '.')}}</p>
        @endforeach
      </div>
      <div class="pagamento">
        <h5>Detalhes de Pagamento</h5>
        <p>Forma de Pagamento: {{$pedido->forma_pagamento}}</p>
        <p>Desconto {{$pedido->desconto}}</p>
        <p>Total {{$pedido->total - $pedido->desconto}}</p>
        
      </div>
    </div>
  </body>
  </html>