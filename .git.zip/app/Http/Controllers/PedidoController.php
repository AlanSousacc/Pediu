<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Movimentacao;
use App\Models\Entregador;
use App\Models\Pedidos;
use App\Models\Contato;
use App\Models\Produto;
use Carbon\Carbon;
use Exception;
use Auth;
use PDF;
use DB;

class PedidoController extends Controller
{
  // carrega todos os dados para a página de listagem de pedidos
  public function index()
  {
    $consulta   = Pedidos::paginate(10);
    $pedido     = Pedidos::all();
    $entregador = Entregador::get();
    
    return view('pages.pedidos.listagemPedidos', compact('consulta', 'entregador', 'pedido'));
  }
  
  // detalha o pedido solicitado e leva para a tela de detalhes do pedido
  public function detalhePedido($id)
  {
    $pedido = Pedidos::find($id);
    return view('pages.pedidos.detalhePedido', compact('pedido'));
  }
  
  // função para aplicar o status do pedido, entregador do pedido.
  public function aplicarStatus(Request $request)
  {
    $data = $request->except('_token');
    try{
      $pedido                  = Pedidos::findOrFail($data['pedidoid']);
      $mov                     = Movimentacao::where('pedido_id', $pedido->id)->first();
      $total                   = $pedido->total;
      
      if(isset($data['entregador_id'])){
        $pedido->entregador_id = $data['entregador_id'];
      }
      
      if($data['troco'] == null){
        $pedido->valortroco == 0;  
      } else{
        $pedido->valortroco = $data['troco'];
        $mov->valortotal    = $total + $data['troco'];
        $savedmov           = $mov->save();
      }
      
    } catch (Exception $e) {
      return redirect()->back()->with('error', $e->getMessage());
      exit();
    }
    
    try{
      DB::beginTransaction();
      
      $saved = $pedido->save();
      
      if (!$saved)
      throw new Exception('Falha ao aplicar status deste Pedido!');
      
      DB::commit();
      return redirect()->back()->with('success', 'Status do pedido aplicado sucesso!');
      
    } catch (Exception $e) {
      
      DB::rollBack();
      return redirect()->back()->with('error', $e->getMessage());
    }
  }
  
  // cria a tela de novo pedido com os dados do banco.
  public function create(){
    $consulta     = Pedidos::whereDay('created_at', date('d'))->orderby('created_at', 'desc')->paginate(10);
    $resumo       = Pedidos::where('pedidos.created_at', '>=', Carbon::now()->sub('hour', 12))->get();
    $resumoEntre  = DB::table('pedidos')
                  ->join('entregadores', 'entregadores.id', '=', 'pedidos.entregador_id')
                  ->select('entregadores.nome as nomeEntregador', (DB::raw('sum(pedidos.total) as somaTotal')))
                  ->where('pedidos.created_at', '>=', Carbon::now()->sub('hour', 12))
                  ->where('pedidos.statusentrega', 0)
                  ->groupBy('pedidos.entregador_id')
                  ->get();
                  
    $movimentacao = Movimentacao::all();
    $contatos     = Contato::all();
    $entregador   = Entregador::all();
    $produtos     = Produto::all();

    return view('pages.pedidos.novoPedido', compact('resumoEntre', 'resumo', 'contatos', 'entregador', 'produtos', 'consulta', 'movimentacao'));
  }
  
  /**
  * Esta função foi projetada para salvar o pedido em questão e também associar os itens do pedido
  * ao pedido atual. Criar uma movimentação para que haja necessidade futuramente de conferencia, 
  * como se fosse um caixa.
  */
  public function store(Request $request) 
  {
    $data = $request->except('_token');
    
    if(count($data['produtos_listagem_id']) < count($data['produtos_qtde']))
    throw new Exception('Quantidade de itens diferente de quantidade de unidade!');
    
    try{
      // dados do pedido
      $pedido                     = new Pedidos;
      $pedido->observacao         = $data['observacao'];
      $pedido->desconto           = $data['desconto'] != null ? $data['desconto'] : 0;
      
      $pedido->local_pagamento    = $data['local_pagamento'];
      $pedido->forma_pagamento    = $data['forma_pagamento'];
      $pedido->contato_id         = $data['contato_id'];
      $pedido->total              = $data['total'] + $pedido->desconto;
      $pedido->subtotal           = $pedido->total - $pedido->desconto;
      if($pedido->forma_pagamento == 'Conta do Cliente') {
        $pedido->valortroco       = 0;
      } else {
        $pedido->valortroco       = $data['troco'] - $pedido->subtotal;
      }
      $pedido->endereco_id        = $data['entrega_id'];
      $pedido->statusentrega      = 0;
      
    } catch (Exception $e) {
      return redirect()->back()->with('error', $e->getMessage());
      exit();
    }
    
    try{
      DB::beginTransaction();
      $pedidosaved = $pedido->save();
      
      // aplica o pedido na movimentação
      $mov                  = new Movimentacao;
      $mov->tipo            = 'Entrada';
      $mov->forma_pagamento = $pedido->forma_pagamento;
      $mov->valortotal      = $pedido->valortroco != null ? $pedido->total + $pedido->valortroco : $pedido->total;
      $mov->valorrecebido   = 0;
      $mov->valorpendente   = $mov->valortotal;
      $mov->status          = 0; //emaberto, aguardando entregador
      $mov->pedido_id       = $pedido->id;
      $mov->contato_id      = $pedido->contato_id;
      
      $movisaved = $mov->save();
      if (!$movisaved)
      throw new Exception('Falha ao salvar Movimentação!');
      
      // dados do pedidoproduto
      foreach($data['produtos_listagem_id'] as $i => $produto_id ){
        $qtde    = $data['produtos_qtde'][$i];
        $obsitem = $data['obsitem'][$i];
        $prvenda = $data['prvenda'][$i];
        
        $pedido->produtos()->attach([
          $produto_id => ['qtde' => $qtde, 'obsitem' => $obsitem, 'prvenda' => $prvenda]
        ]);
      }
        
        if (!$pedidosaved)
        throw new Exception('Falha ao salvar Pedido!');
        
        DB::commit();
        return redirect()->back()->with('pedido', $pedido->id);

      } catch (Exception $e) {
        
        DB::rollBack();
        return redirect()->back()->with('error', $e->getMessage());
      }
    }
    
    // tela de alteração do pedido
    public function edit($id)
    {
      $pedido     = Pedidos::find($id);
      $contatos   = Contato::all();
      $produtos   = Produto::all();
      
      return view('pages.pedidos.editar', compact('pedido', 'contatos', 'produtos'));
    }
    
    /**
    * Esta função foi projetada para salvar o pedido em questão e também associar os itens do pedido
    * ao pedido atual. Criar uma movimentação para que haja necessidade futuramente de conferencia, 
    * como se fosse um caixa.
    */
    public function update(Request $request, $id)
    {
      $data = $request->except('_token');
      
      if(count($data['produtos_listagem_id']) < count($data['produtos_qtde']))
      throw new Exception('Quantidade de itens diferente de quantidade de unidade!');
      
      try{
        
        $pedido                  = Pedidos::findOrFail($id);
        $pedido->observacao      = $data['observacao'];
        $pedido->desconto        = $data['desconto'] != null ? $data['desconto'] : 0;
        $pedido->local_pagamento = $data['local_pagamento'];
        $pedido->forma_pagamento = $data['forma_pagamento'];
        $pedido->contato_id      = $data['contato_id'];
        $pedido->total           = $data['total'] + $pedido->desconto;
        $pedido->subtotal        = $pedido->total - $pedido->desconto; 
        $pedido->valortroco      = $data['troco'] - $pedido->subtotal;
        $pedido->endereco_id     = $data['entrega_id'];
        $pedido->statusentrega   = 0;
        
      } catch (Exception $e) {
        return redirect()->back()->with('error', $e->getMessage());
        exit();
      }
      
      try{
        DB::beginTransaction();
        
        $saved = $pedido->save();
        
        // aplica o pedido na movimentação
        $mov                  = Movimentacao::where('pedido_id', $pedido->id)->first();
        $mov->tipo            = 'Entrada';
        $mov->forma_pagamento = $pedido->forma_pagamento;
        $mov->valortotal      = $pedido->total;
        $mov->valorrecebido   = 0;
        $mov->valorpendente   = $mov->valortotal;
        $mov->status          = 0; //emaberto, aguardando entregador
        $mov->pedido_id       = $pedido->id;
        $mov->contato_id      = $pedido->contato_id;
        
        $savemovi = $mov->save();
        if (!$savemovi)
        throw new Exception('Falha ao alterar o Pedido e Movimentação!');
        
        $produtos = [];
        
        foreach($data['produtos_listagem_id'] as $i => $produto_id ){
          $qtde    = $data['produtos_qtde'][$i];
          $obsitem = $data['obsitem'][$i] != "null" ? $data['obsitem'][$i] : null;
          $prvenda = $data['prvenda'][$i];
          
          $produtos[$produto_id] = ['qtde' => $qtde, 'obsitem' => $obsitem, 'prvenda' => $prvenda];
        }
        
        $pedido->produtos()->sync($produtos);
        
        if (!$saved)
        throw new Exception('Falha ao alterar o Pedido!');
        
        DB::commit();
        return redirect()->back()->with('success', 'Pedido alterado com sucesso!');
        
      } catch (Exception $e) {
        
        DB::rollBack();
        return redirect()->back()->with('error', $e->getMessage());
      }
    }
    
    public function destroy(Request $request)
    {
      try{
        $pedido   = Pedidos::find($request->pedido_id);
        $mov      = Movimentacao::where('pedido_id', $pedido->id)->first();
        
        $savedmov = $mov->delete();
        if (!$savedmov){
          throw new Exception('Falha ao remover a movimentação!');
        }
        
        if (!$pedido)
        throw new Exception("Nenhum Pedido encontrado!");
        
        if ($pedido->statusentrega == 3)
        throw new Exception("Este pedido não pode ser removido pois já foi entregue!");
        
        $pedido->produtos()->detach();
        
      } catch (Exception $e) {
        return redirect()->back()->with('error', $e->getMessage());
        exit();
      }
      
      try{
        DB::beginTransaction();
        
        $saved = $pedido->delete();
        
        if (!$saved){
          throw new Exception('Falha ao remover este pedido!');
        }
        DB::commit();
        // se chegou aqui é pq deu tudo certo
        return redirect()->back()->with('success', 'Pedido #' . $pedido->id . ' removido com sucesso!');
      } catch (Exception $e) {
        DB::rollBack();
        
        return redirect()->back()->with('error', $e->getMessage());
      }
    }

    public function resumoPeriodo(Request $request){
      $data = $request->except('_toquen');

      if(!empty($data['dtstart']) && !empty($data['dtstart'])){
        $data['dtstart'] = Carbon::parse($data['dtstart'])->format('Y-d-m H:m:s');
        $data['dtend'] 	 = Carbon::parse($data['dtend'])->format('Y-d-m H:m:s');
      }

		  // if(!empty($data['dtend']))

      if(isset($data['dtstart']) && isset($data['dtend'])){
        $resumo      = Pedidos::whereBetween('created_at', [$data['dtstart'], $data['dtend']])->get();
        $resumoEntre = DB::table('pedidos')
                   ->join('entregadores', 'entregadores.id', '=', 'pedidos.entregador_id')
                   ->select('entregadores.nome as nomeEntregador', (DB::raw('sum(pedidos.total) as somaTotal')))
                   ->whereBetween('pedidos.created_at', [$data['dtstart'], $data['dtend']])
                   ->where('pedidos.statusentrega', 0)
                   ->groupBy('pedidos.entregador_id')
                   ->get();
      } else {
        $resumo      = Pedidos::where('created_at', Carbon::now()->sub('hour', 12))->get();
        $resumoEntre = DB::table('pedidos')
                  ->join('entregadores', 'entregadores.id', '=', 'pedidos.entregador_id')
                  ->select('entregadores.nome as nomeEntregador', (DB::raw('sum(pedidos.total) as somaTotal')))
                  ->where('pedidos.created_at', '>=', Carbon::now()->sub('hour', 12))
                  ->where('pedidos.statusentrega', 0)
                  ->groupBy('pedidos.entregador_id')
                  ->get();
      }

      $contatos     = Contato::all();
      $entregador   = Entregador::all();
      $produtos     = Produto::all();
      $movimentacao = Movimentacao::all();
      $consulta     = Pedidos::whereDay('created_at', date('d'))->orderby('created_at', 'desc')->paginate(10);
        
      return view('pages.pedidos.novoPedido', compact('movimentacao', 'resumo', 'contatos', 'entregador', 'produtos', 'consulta', 'resumoEntre'));
    }
    
    public function imprimirPedido($id){
      $pedido = Pedidos::find($id);

      return PDF::loadView('pages.pedidos.pdf.order', compact('pedido'))
      ->setPaper(array(10,0,204,650))
			->stream('pedido '.$id.'.pdf');
    }

    public function print($id){
      $pedido = Pedidos::find($id);

      return PDF::loadView('pages.pedidos.pdf.order', compact('pedido'))
      ->setPaper(array(5,0,204,650))
			->stream('pedido '.$id.'.pdf');
    }
  }
  