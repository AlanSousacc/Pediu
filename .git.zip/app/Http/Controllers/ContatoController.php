<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\ContatoRequest;
use Illuminate\Support\Facades\DB;

use App\Models\Contato;
use App\Models\Endereco;
use App\Models\Movimentacao;
use Exception;
use Auth;

class ContatoController extends Controller
{
  public function index()
  {
    $consulta = Contato::paginate(10);
    return view('pages.contatos.listagemContato', compact('consulta'));
  }

  public function listaFinanceiroContato($id){
    $contato      = Contato::findOrFail($id);
    $movimentacao = Movimentacao::where('contato_id', $id)->paginate(10);
    return view('pages.contatos.listagemFinanceiroContato', compact('contato', 'movimentacao'));
  }

  public function create(){
    return view('pages.contatos.novoContato');
  }

  public function store(ContatoRequest $request) {
    $data = $request->except('_token');

    try{
      $contato 			       = new Contato;
      $contato->nome       = $data['nome'];
      $contato->documento  = $data['documento'];
      $contato->telefone   = $data['telefone'];
      $contato->tipo       = $data['tipo'];

    } catch (Exception $e) {
      return redirect()->back()->with('error', $e->getMessage());
      exit();
    }

    try{
			DB::beginTransaction();
			
      $saved = $contato->save();

      if (!$saved)
        throw new Exception('Falha ao salvar este contato!');

      // CADASTRA O ENDEREÇO AO CLIENTE
      $endereco 						      = new Endereco;
			$endereco->endereco  	      = $data['endereco'];
			$endereco->numero  		      = $data['numero'];
			$endereco->bairro  		      = $data['bairro'];
			$endereco->cidade  		      = $data['cidade'];
			$endereco->observacao       = $data['observacao'];
			$endereco->cep  			      = $data['cep'];
			$endereco->telefone_entrega = $data['telefone_entrega'];
      $endereco->status  		      = $data['status'];
      $endereco->principal	      = $data['principal'];
			$endereco->contato_id	      = $contato->id;
      $saved								      = $endereco->save();

      
      if (!$saved){
				throw new Exception('Falha ao salvar Endereço!');
			}

			DB::commit();
			return redirect()->back()->with('success', 'Contato criado com sucesso!');

    } catch (Exception $e) {

      DB::rollBack();
      return redirect()->back()->with('error', $e->getMessage());
    }
  }

  public function edit($id)
	{
    $contato = Contato::find($id);
    $entrega = Endereco::where('contato_id', $id)->first();
		return view('pages.contatos.editar', compact('contato', 'entrega'));
	}

  public function update(ContatoRequest $request, $id)
  {
    $data = $request->except('_token');
    
    try{
      $contato = Contato::find($id);
      if (!$contato)
        throw new Exception("Nenhum contato encontrado");

      $contato->nome       = $data['nome'];
      $contato->documento  = $data['documento'];
      $contato->telefone   = $data['telefone'];
      $contato->tipo       = $data['tipo'];
      $saved               = $contato->save();
      if (!$saved)
      throw new Exception('Falha ao alterar este contato!');

        // CADASTRA O ENDEREÇO AO CLIENTE
      $endereco                   = Endereco::where('contato_id', $id)->first();
			$endereco->endereco  	      = $data['endereco'];
			$endereco->numero  		      = $data['numero'];
			$endereco->bairro  		      = $data['bairro'];
			$endereco->cidade  		      = $data['cidade'];
			$endereco->observacao       = $data['observacao'];
			$endereco->cep  			      = $data['cep'];
			$endereco->telefone_entrega = $data['telefone_entrega'];
      $endereco->status  		      = $data['status'];
      $endereco->principal	      = $data['principal'];
			$endereco->contato_id	      = $contato->id;

    } catch (Exception $e) {
      return redirect()->back()->with('error', $e->getMessage());
      exit();
    }

    try{
      DB::beginTransaction();
      
      $saved = $endereco->save();
      
      if (!$saved){
				throw new Exception('Falha ao alterar Endereço!');
			}

			DB::commit();
			return redirect()->back()->with('success', 'Contato alterado com sucesso!');

    } catch (Exception $e) {

      DB::rollBack();
      return redirect()->back()->with('error', $e->getMessage());
    }
  }

  public function destroy(Request $request)
  {
    try{
			$contato = Contato::find($request->contato_id);
      $entrega = Endereco::where('contato_id', $request->contato_id)->get();

      if (!$contato)
        throw new Exception("Nenhum contato encontrado!");
      
      if (count($entrega) > 0)
        throw new Exception("Existem endereços relacionados a este contato!");
      
    } catch (Exception $e) {
      return redirect()->back()->with('error', $e->getMessage());
      exit();
    }
    
    try{
      DB::beginTransaction();
      
      $saved = $contato->delete();
      if (!$saved){
        throw new Exception('Falha ao remover este contato!');
      }
      DB::commit();
      // se chegou aqui é pq deu tudo certo
      return redirect()->back()->with('success', 'Contato #' . $contato->id . ' removido com sucesso!');
    } catch (Exception $e) {
			DB::rollBack();

      return redirect()->back()->with('error', $e->getMessage());
    }
  }
}
