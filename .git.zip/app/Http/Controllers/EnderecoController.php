<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\EnderecoRequest;
use Illuminate\Support\Facades\DB;

use App\Models\Endereco;
use App\Models\Contatos;
use Exception;

class EnderecoController extends Controller
{
  public function index()
  {
    $consulta = Endereco::paginate(10);
    return view('pages.enderecos.listagemEndereco', compact('consulta'));
  }
  
  public function listaEnderecoContato($id)
  {
    $consulta = Endereco::Where('contato_id', $id)->paginate(10);
    return view('pages.enderecos.listagemEndereco', compact('consulta', 'id'));
  }
  
  public function createEndereco($id){
    return view('pages.enderecos.novoEndereco', compact('id'));
  }
  
  public function returnEndereco($id)
  {
    $entrega = Endereco::where('contato_id', $id)->get();    
    
    return response()->json([
      "data" => $entrega
    ]);
  }
    
  public function store(EnderecoRequest $request) {
    $data = $request->except('_token');
    
    try{
      $endereco 						      = new Endereco;
      $endereco->endereco  	      = $data['endereco'];
      $endereco->numero  		      = $data['numero'];
      $endereco->bairro  		      = $data['bairro'];
      $endereco->cidade  		      = $data['cidade'];
      $endereco->observacao       = $data['observacao'];
      $endereco->cep  			      = $data['cep'];
      $endereco->telefone_entrega = $data['telefone_entrega'];
      $endereco->status  		      = $data['status'];
      $endereco->principal	      = $data['principal'];
      $endereco->contato_id	      = $data['contato_id'];
      
    } catch (Exception $e) {
      return redirect()->back()->with('error', $e->getMessage());
      exit();
    }
    
    try{
      
      DB::beginTransaction();
      
      $saved = $endereco->save();
      
      if (!$saved)
      throw new Exception('Falha ao salvar este Local de Entrega!');
      
      DB::commit();
      return redirect()->back()->with('success', 'Local de Entrega criado com sucesso!');
      
    } catch (Exception $e) {
      
      DB::rollBack();
      return redirect()->back()->with('error', $e->getMessage());
    }
  }
  
  public function edit($id)
  {
    $entrega = Endereco::find($id);
    return view('pages.enderecos.editar', compact('entrega'));
  }
  
  public function update(EnderecoRequest $request, $id)
  {
    $data = $request->except('_token');
    
    try{
      $endereco = Endereco::find($id);
      if (!$endereco)
      throw new Exception("Nenhum endereço de entrega encontrado");
      
      $endereco->endereco  	      = $data['endereco'];
      $endereco->numero  		      = $data['numero'];
      $endereco->bairro  		      = $data['bairro'];
      $endereco->cidade  		      = $data['cidade'];
      $endereco->observacao       = $data['observacao'];
      $endereco->cep  			      = $data['cep'];
      $endereco->telefone_entrega = $data['telefone_entrega'];
      $endereco->status  		      = $data['status'];
      $endereco->principal	      = $data['principal'];
      $endereco->contato_id	      = $data['contato_id'];
      $saved = $endereco->save();
      
      if (!$saved)
      throw new Exception('Falha ao alterar este Endereço de Entrega!');
      
    } catch (Exception $e) {
      return redirect()->back()->with('error', $e->getMessage());
      exit();
    }
    
    try{
      DB::beginTransaction();
      
      if (!$saved){
        throw new Exception('Falha ao alterar Endereço!');
      }
      
      DB::commit();
      return redirect()->back()->with('success', 'Contato alterado com sucesso!');
      
    } catch (Exception $e) {
      
      DB::rollBack();
      return redirect()->back()->with('error', $e->getMessage());
    }
  }
  
  public function destroy(Request $request)
  {
    try{
      $entrega = Endereco::find($request->contato_id);
      
      if (!$entrega)
      throw new Exception("Nenhum Endereço de entrega encontrado!");
      
    } catch (Exception $e) {
      return redirect()->back()->with('error', $e->getMessage());
      exit();
    }
    
    try{
      DB::beginTransaction();
      
      $saved = $entrega->delete();
      if (!$saved){
        throw new Exception('Falha ao remover este Endereço de entrega!');
      }
      DB::commit();
      // se chegou aqui é pq deu tudo certo
      return redirect()->back()->with('success', 'Endereço de entrega #' . $entrega->id . ' removido com sucesso!');
    } catch (Exception $e) {
      DB::rollBack();
      
      return redirect()->back()->with('error', $e->getMessage());
    }
  }
}
  