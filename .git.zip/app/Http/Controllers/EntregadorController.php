<?php

namespace App\Http\Controllers;

use App\Http\Requests\EntregadorRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

use App\Models\Entregador;
use Exception;
use Auth;

class EntregadorController extends Controller
{
  public function index()
  {
    $consulta = Entregador::paginate(10);
    return view('pages.entregadores.listagemEntregador', compact('consulta'));
  }

  public function create(){
    return view('pages.entregadores.novoEntregador');
  }

  public function store(EntregadorRequest $request) {
    $data = $request->except('_token');

    try{
      $entregador		         = new Entregador;
      $entregador->nome      = $data['nome'];
      $entregador->endereco  = $data['endereco'];
      $entregador->numero    = $data['numero'];
      $entregador->cidade    = $data['cidade'];
      $entregador->bairro    = $data['bairro'];
      $entregador->telefone  = $data['telefone'];
      $entregador->cep       = $data['cep'];
      $entregador->veiculo   = $data['veiculo'];
      $entregador->placa     = $data['placa'];
      $entregador->status    = $data['status'];

    } catch (Exception $e) {
      return redirect()->back()->with('error', $e->getMessage());
      exit();
    }

    try{
			DB::beginTransaction();
			
      $saved = $entregador->save();

      if (!$saved)
        throw new Exception('Falha ao salvar este Entregador!');

			DB::commit();
			return redirect()->back()->with('success', 'Entregador criado com sucesso!');

    } catch (Exception $e) {

      DB::rollBack();
      return redirect()->back()->with('error', $e->getMessage());
    }
  }

  public function edit($id)
	{
    $entregador = Entregador::find($id);
		return view('pages.entregadores.editar', compact('entregador'));
	}

  public function update(EntregadorRequest $request, $id)
  {
    $data = $request->except('_token');

    try{
      $entregador = Entregador::find($id);

      if (!$entregador)
        throw new Exception("Nenhum Entregador encontrado");

      $entregador->nome      = $data['nome'];
      $entregador->endereco  = $data['endereco'];
      $entregador->numero    = $data['numero'];
      $entregador->cidade    = $data['cidade'];
      $entregador->bairro    = $data['bairro'];
      $entregador->telefone  = $data['telefone'];
      $entregador->cep       = $data['cep'];
      $entregador->veiculo   = $data['veiculo'];
      $entregador->placa     = $data['placa'];
      $entregador->status    = $data['status'];
      $saved = $entregador->save();

    } catch (Exception $e) {
      return redirect()->back()->with('error', $e->getMessage());
      exit();
    }

    try{
      DB::beginTransaction();
      
      if (!$saved){
				throw new Exception('Falha ao alterar Entregador!');
			}

			DB::commit();
			return redirect()->back()->with('success', 'Entregador alterado com sucesso!');

    } catch (Exception $e) {

      DB::rollBack();
      return redirect()->back()->with('error', $e->getMessage());
    }
  }

  public function destroy(Request $request)
  {
    try{
			$entregador = Entregador::find($request->entregador_id);

      if (!$entregador)
        throw new Exception("Nenhum Entregador encontrado!");
      
    } catch (Exception $e) {
      return redirect()->back()->with('error', $e->getMessage());
      exit();
    }
    
    try{
      DB::beginTransaction();
      
      $saved = $entregador->delete();

      if (!$saved){
        throw new Exception('Falha ao remover este Entregador!');
      }
      DB::commit();
      // se chegou aqui é pq deu tudo certo
      return redirect()->back()->with('success', 'Entregador #' . $entregador->id . ' removido com sucesso!');
    } catch (Exception $e) {
			DB::rollBack();

      return redirect()->back()->with('error', $e->getMessage());
    }
  }
}
